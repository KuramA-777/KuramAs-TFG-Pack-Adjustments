// priority 10



let hidePotions = (/** @type {Internal.HideJEIEventJS}*/ event) => {
  
  
  // Thorium Reactors
    event.hide('thoriumreactors:generator_block')
    event.hide('thoriumreactors:fluid_evaporation_block')
    event.hide('thoriumreactors:electrolytic_salt_separator')
    event.hide('thoriumreactors:salt_melter_block')
    event.hide('thoriumreactors:concentrator_block')
    event.hide('thoriumreactors:decomposer_block')
    event.hide('thoriumreactors:uranium_oxidizer_block')
    event.hide('thoriumreactors:fluid_centrifuge_block')
    event.hide('thoriumreactors:crystallizer_block')
    event.hide('thoriumreactors:blast_furnace_block')
    event.hide('thoriumreactors:fluid_enricher_block')
    event.hide('thoriumreactors:sodium')
    event.hide('thoriumreactors:potassium')
    event.hide('thoriumreactors:raw_uranium')
    event.hide('thoriumreactors:fluorite')
    event.hide('thoriumreactors:uran_three_chloride')
}
